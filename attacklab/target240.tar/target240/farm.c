/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_422(unsigned *p)
{
    *p = 3347662968U;
}

void setval_124(unsigned *p)
{
    *p = 3351742792U;
}

void setval_137(unsigned *p)
{
    *p = 2428995912U;
}

unsigned getval_308()
{
    return 2428995914U;
}

unsigned addval_144(unsigned x)
{
    return x + 2425393496U;
}

unsigned addval_150(unsigned x)
{
    return x + 2425393240U;
}

unsigned getval_299()
{
    return 2438518300U;
}

unsigned addval_394(unsigned x)
{
    return x + 2421689136U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_488()
{
    return 2425406089U;
}

void setval_347(unsigned *p)
{
    *p = 2425409033U;
}

void setval_165(unsigned *p)
{
    *p = 2429659557U;
}

unsigned addval_463(unsigned x)
{
    return x + 2425668233U;
}

unsigned getval_234()
{
    return 2428666157U;
}

unsigned addval_115(unsigned x)
{
    return x + 3286272328U;
}

unsigned addval_307(unsigned x)
{
    return x + 3348156809U;
}

void setval_199(unsigned *p)
{
    *p = 3353381192U;
}

unsigned addval_249(unsigned x)
{
    return x + 3526414729U;
}

unsigned addval_148(unsigned x)
{
    return x + 3221279113U;
}

unsigned getval_269()
{
    return 3524841865U;
}

void setval_295(unsigned *p)
{
    *p = 3281047177U;
}

unsigned addval_337(unsigned x)
{
    return x + 2447411528U;
}

unsigned getval_487()
{
    return 2764295809U;
}

unsigned getval_450()
{
    return 2464188744U;
}

void setval_333(unsigned *p)
{
    *p = 3523793289U;
}

unsigned addval_266(unsigned x)
{
    return x + 3674784395U;
}

unsigned getval_328()
{
    return 3525366153U;
}

void setval_382(unsigned *p)
{
    *p = 3525886601U;
}

void setval_335(unsigned *p)
{
    *p = 3286272840U;
}

unsigned addval_499(unsigned x)
{
    return x + 3221799560U;
}

unsigned getval_198()
{
    return 3531915977U;
}

void setval_395(unsigned *p)
{
    *p = 2425409160U;
}

void setval_162(unsigned *p)
{
    *p = 3286272328U;
}

unsigned addval_332(unsigned x)
{
    return x + 3252717896U;
}

unsigned addval_283(unsigned x)
{
    return x + 3281047181U;
}

void setval_454(unsigned *p)
{
    *p = 2428668408U;
}

unsigned addval_158(unsigned x)
{
    return x + 3676360361U;
}

void setval_405(unsigned *p)
{
    *p = 3223375497U;
}

unsigned addval_133(unsigned x)
{
    return x + 2497743176U;
}

void setval_451(unsigned *p)
{
    *p = 3524841865U;
}

unsigned getval_106()
{
    return 3225996937U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
